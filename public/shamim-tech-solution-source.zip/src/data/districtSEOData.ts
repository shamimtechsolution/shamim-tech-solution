export * from '../seo/districtSEOData';
