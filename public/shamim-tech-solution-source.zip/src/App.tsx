import React, { useState, useEffect, useCallback } from 'react';
import { Navbar } from './components/Navbar';
import { Hero } from './components/Hero';
import { ServicesSection } from './components/ServicesSection';
import { ProductShop } from './components/ProductShop';
import { ProductDetailModal } from './components/ProductDetailModal';
import { CartDrawer } from './components/CartDrawer';
import { OrderModal } from './components/OrderModal';

import { WorkGallery } from './components/WorkGallery';
import { CustomerReviews } from './components/CustomerReviews';
import { ContactSection } from './components/ContactSection';
import { Footer } from './components/Footer';
import { FloatingActions } from './components/FloatingActions';
import { AdminLoginModal } from './components/AdminLoginModal';
import { AdminDashboard } from './components/AdminDashboard';
import { AdminLoginPage } from './components/AdminLoginPage';
import { CustomerAuthModal } from './components/CustomerAuthModal';
import { CustomerProfileModal } from './components/CustomerProfileModal';
import { DISTRICT_SEO_DATA } from './data/districtSEOData';
import { SERVICES_SEO_DATA } from './data/servicesSEOData';
import { PRODUCTS_SEO_DATA } from './data/productsSEOData';
import { 
  INITIAL_PRODUCTS as PRODUCTS_CATALOG, 
  SOFTWARE_DOWNLOADS, 
  COMPANY_INFO, 
  DEFAULT_SITE_CONTENT 
} from './data/companyData';
import { Product, CartItem, SavedOrder, CompanyInfo, SiteContent, DownloadItem, CustomerUser, ProductCategory } from './types';
import { getStoredCustomerUser, apiGetCustomerProfile, clearCustomerSession } from './utils/customerAuth';
import { getProductsFromFirestore, subscribeToProducts, seedInitialProductsIfEmpty } from './firebase/productService';

export default function App() {
  // Shopping Cart state with localStorage persistence
  const [cartItems, setCartItems] = useState<CartItem[]>(() => {
    try {
      const saved = localStorage.getItem('sts_cctv_cart');
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  // Dynamic Content States synchronized with backend database and localStorage backup
  const [products, setProducts] = useState<Product[]>(() => {
    try {
      const stored = localStorage.getItem('sts_custom_products');
      if (stored) {
        const parsed = JSON.parse(stored);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch {}
    return PRODUCTS_CATALOG;
  });
  const [downloads, setDownloads] = useState<DownloadItem[]>(SOFTWARE_DOWNLOADS);
  const [companyInfo, setCompanyInfo] = useState<CompanyInfo>(COMPANY_INFO);
  const [siteContent, setSiteContent] = useState<SiteContent>(DEFAULT_SITE_CONTENT);

  // Admin Control System state
  const checkIsAdminPath = () => {
    if (typeof window === 'undefined') return false;
    const path = window.location.pathname.toLowerCase();
    const hash = window.location.hash.toLowerCase();
    const search = window.location.search.toLowerCase();
    return (
      path === '/admin' || 
      path.startsWith('/admin/') || 
      hash === '#admin' || 
      hash.startsWith('#admin') ||
      search.includes('admin=true') ||
      search.includes('admin=1') ||
      search.includes('admin')
    );
  };

  const [isAdminRoute, setIsAdminRoute] = useState<boolean>(checkIsAdminPath);
  const [adminToken, setAdminToken] = useState<string | null>(() => {
    return localStorage.getItem('sts_admin_token') || null;
  });
  const [adminUser, setAdminUser] = useState<{ username: string; email: string; role: string } | null>(null);
  const [isAdminLoggedIn, setIsAdminLoggedIn] = useState<boolean>(false);
  const [isAdminLoginOpen, setIsAdminLoginOpen] = useState(false);
  const [isAdminDashboardOpen, setIsAdminDashboardOpen] = useState(false);

  // 8 District Service Area SEO Routing
  const checkDistrictRoute = (): string | null => {
    if (typeof window === 'undefined') return null;
    const path = window.location.pathname.toLowerCase();
    const hash = window.location.hash.toLowerCase();
    const match = path.match(/^\/service-area\/([a-z0-9\-]+)/);
    if (match && match[1] && DISTRICT_SEO_DATA[match[1]]) return match[1];
    const hashMatch = hash.match(/^#service-area\/([a-z0-9\-]+)/);
    if (hashMatch && hashMatch[1] && DISTRICT_SEO_DATA[hashMatch[1]]) return hashMatch[1];
    const urlParams = new URLSearchParams(window.location.search);
    const dist = urlParams.get('district');
    if (dist && DISTRICT_SEO_DATA[dist.toLowerCase()]) return dist.toLowerCase();
    return null;
  };

  // 54 Dedicated Services SEO Routing
  const checkServiceRoute = (): string | null => {
    if (typeof window === 'undefined') return null;
    const path = window.location.pathname.toLowerCase();
    const hash = window.location.hash.toLowerCase();
    const match = path.match(/^\/services\/([a-z0-9\-]+)/);
    if (match && match[1] && SERVICES_SEO_DATA[match[1]]) return match[1];
    const hashMatch = hash.match(/^#services\/([a-z0-9\-]+)/);
    if (hashMatch && hashMatch[1] && SERVICES_SEO_DATA[hashMatch[1]]) return hashMatch[1];
    const urlParams = new URLSearchParams(window.location.search);
    const s = urlParams.get('service');
    if (s && SERVICES_SEO_DATA[s.toLowerCase()]) return s.toLowerCase();
    return null;
  };

  // 56 Dedicated Products SEO Routing
  const checkProductRoute = (): string | null => {
    if (typeof window === 'undefined') return null;
    const path = window.location.pathname.toLowerCase();
    const hash = window.location.hash.toLowerCase();
    const match = path.match(/^\/products\/([a-z0-9\-]+)/);
    if (match && match[1] && PRODUCTS_SEO_DATA[match[1]]) return match[1];
    const hashMatch = hash.match(/^#products\/([a-z0-9\-]+)/);
    if (hashMatch && hashMatch[1] && PRODUCTS_SEO_DATA[hashMatch[1]]) return hashMatch[1];
    const urlParams = new URLSearchParams(window.location.search);
    const p = urlParams.get('product');
    if (p && PRODUCTS_SEO_DATA[p.toLowerCase()]) return p.toLowerCase();
    return null;
  };

  const [activeDistrictSlug, setActiveDistrictSlug] = useState<string | null>(checkDistrictRoute);
  const [activeServiceSlug, setActiveServiceSlug] = useState<string | null>(checkServiceRoute);
  const [activeProductSlug, setActiveProductSlug] = useState<string | null>(checkProductRoute);

  // UI state
  const [activeSection, setActiveSection] = useState('home');
  const [isCartOpen, setIsCartOpen] = useState(false);
  const [isOrderModalOpen, setIsOrderModalOpen] = useState(false);
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null);
  const [selectedCategory, setSelectedCategory] = useState<ProductCategory>('All Products');
  const [searchTerm, setSearchTerm] = useState('');
  const [preselectedService, setPreselectedService] = useState<string>('');
  const [toastMessage, setToastMessage] = useState<string | null>(null);

  // Customer User Authentication states
  const [customer, setCustomer] = useState<CustomerUser | null>(getStoredCustomerUser);
  const [isCustomerAuthOpen, setIsCustomerAuthOpen] = useState(false);
  const [customerAuthMode, setCustomerAuthMode] = useState<'register' | 'login' | 'forgot'>('register');
  const [isCustomerProfileOpen, setIsCustomerProfileOpen] = useState(false);
  const [isContactModalOpen, setIsContactModalOpen] = useState(false);

  // Load public data from live Express backend with localStorage persistence
  const loadPublicData = useCallback(async () => {
    try {
      let res = await fetch('/api/public/data');
      let contentType = res.headers.get('content-type') || '';
      if (!res.ok || !contentType.includes('application/json')) {
        // Fallback for static hosts (e.g. Vercel)
        res = await fetch('/data/public-data.json');
        contentType = res.headers.get('content-type') || '';
      }

      if (res.ok && contentType.includes('application/json')) {
        const data = await res.json();
        if (data.products && Array.isArray(data.products) && data.products.length > 0) {
          setProducts(data.products);
          try {
            localStorage.setItem('sts_custom_products', JSON.stringify(data.products));
          } catch {}
        }
        if (data.downloads && Array.isArray(data.downloads) && data.downloads.length > 0) {
          setDownloads(data.downloads);
        }
        if (data.companyInfo) {
          setCompanyInfo(data.companyInfo);
        }
        if (data.siteContent) {
          setSiteContent(data.siteContent);
        }
      } else {
        const stored = localStorage.getItem('sts_custom_products');
        if (stored) {
          const parsed = JSON.parse(stored);
          if (Array.isArray(parsed) && parsed.length > 0) setProducts(parsed);
        }
      }
    } catch (err) {
      console.warn('Backend public data fetch note: using local fallback defaults.', err);
      const stored = localStorage.getItem('sts_custom_products');
      if (stored) {
        try {
          const parsed = JSON.parse(stored);
          if (Array.isArray(parsed) && parsed.length > 0) setProducts(parsed);
        } catch {}
      }
    }
  }, []);

  // Synchronize products with Firebase Firestore in real-time across all visitors
  useEffect(() => {
    // 1. Initial attempt from Firestore
    getProductsFromFirestore()
      .then(items => {
        if (items && items.length > 0) {
          setProducts(items);
          try {
            localStorage.setItem('sts_custom_products', JSON.stringify(items));
          } catch {}
        } else {
          loadPublicData();
        }
      })
      .catch(err => {
        console.warn('Firestore initial fetch fallback:', err);
        loadPublicData();
      });

    // 2. Real-time subscription to Firestore collection 'products'
    let unsubscribe: (() => void) | undefined;
    try {
      unsubscribe = subscribeToProducts(
        firestoreProducts => {
          if (firestoreProducts && firestoreProducts.length > 0) {
            setProducts(firestoreProducts);
            try {
              localStorage.setItem('sts_custom_products', JSON.stringify(firestoreProducts));
            } catch {}
          }
        },
        err => {
          console.warn('Firestore subscription fallback:', err);
        }
      );
    } catch (subErr) {
      console.warn('Real-time subscription init notice:', subErr);
    }

    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, [loadPublicData]);

  // Listen to manual product updates from admin dashboard
  useEffect(() => {
    const handleProductsUpdated = () => {
      try {
        const stored = localStorage.getItem('sts_custom_products');
        if (stored) {
          const parsed = JSON.parse(stored);
          if (Array.isArray(parsed) && parsed.length > 0) {
            setProducts(parsed);
          }
        }
      } catch {}
      loadPublicData();
    };
    window.addEventListener('sts_products_updated', handleProductsUpdated);
    return () => {
      window.removeEventListener('sts_products_updated', handleProductsUpdated);
    };
  }, [loadPublicData]);

  // Verify Admin Session on mount or token change
  useEffect(() => {
    const checkAdminAuth = async () => {
      const token = localStorage.getItem('sts_admin_token');
      if (!token) {
        setIsAdminLoggedIn(false);
        setAdminUser(null);
        return;
      }

      try {
        const res = await fetch('/api/auth/me', {
          headers: {
            'Authorization': `Bearer ${token}`
          }
        });

        if (res.ok) {
          const data = await res.json();
          if (data.authenticated) {
            setIsAdminLoggedIn(true);
            setAdminUser(data.user);
            setAdminToken(token);
          } else {
            localStorage.removeItem('sts_admin_token');
            setIsAdminLoggedIn(false);
            setAdminUser(null);
            setAdminToken(null);
          }
        } else {
          localStorage.removeItem('sts_admin_token');
          setIsAdminLoggedIn(false);
          setAdminUser(null);
          setAdminToken(null);
        }
      } catch (err) {
        console.warn('Auth verification check offline/fallback.', err);
      }
    };

    checkAdminAuth();
    
    // Verify Customer Session
    apiGetCustomerProfile().then(res => {
      if (res.success && res.customer) {
        setCustomer(res.customer);
      } else {
        setCustomer(null);
      }
    });

    loadPublicData();
  }, [loadPublicData]);

  // Synchronize route between browser URL (/admin, #admin, /service-area/:district, /services/:slug, /products/:slug) and application state
  useEffect(() => {
    const handleRouteSync = () => {
      setIsAdminRoute(checkIsAdminPath());
      setActiveDistrictSlug(checkDistrictRoute());
      setActiveServiceSlug(checkServiceRoute());
      setActiveProductSlug(checkProductRoute());
    };
    window.addEventListener('popstate', handleRouteSync);
    window.addEventListener('hashchange', handleRouteSync);
    return () => {
      window.removeEventListener('popstate', handleRouteSync);
      window.removeEventListener('hashchange', handleRouteSync);
    };
  }, []);

  // Synchronize SEO metadata (District, Service, Product) while ALWAYS preserving original main website design
  useEffect(() => {
    if (typeof document === 'undefined') return;

    const setMetaTag = (selector: string, attrName: string, attrValue: string, content: string) => {
      let el = document.querySelector(selector);
      if (!el) {
        el = document.createElement('meta');
        el.setAttribute(attrName, attrValue);
        document.head.appendChild(el);
      }
      el.setAttribute('content', content);
    };

    const setCanonical = (href: string) => {
      let canonical = document.querySelector('link[rel="canonical"]');
      if (!canonical) {
        canonical = document.createElement('link');
        canonical.setAttribute('rel', 'canonical');
        document.head.appendChild(canonical);
      }
      canonical.setAttribute('href', href);
    };

    const updateDynamicRobots = (noindex?: boolean) => {
      let dynamicRobots = document.querySelector('meta[name="robots"][data-dynamic-robots="true"]');
      if (noindex) {
        if (!dynamicRobots) {
          dynamicRobots = document.createElement('meta');
          dynamicRobots.setAttribute('name', 'robots');
          dynamicRobots.setAttribute('data-dynamic-robots', 'true');
          document.head.appendChild(dynamicRobots);
        }
        dynamicRobots.setAttribute('content', 'noindex, follow');
      } else if (dynamicRobots) {
        dynamicRobots.remove();
      }
    };

    const setRouteJsonLd = (data: object | null) => {
      const scriptId = 'route-seo-jsonld';
      let script = document.getElementById(scriptId) as HTMLScriptElement | null;
      if (!data) {
        if (script) script.remove();
        return;
      }
      if (!script) {
        script = document.createElement('script');
        script.id = scriptId;
        script.type = 'application/ld+json';
        document.head.appendChild(script);
      }
      script.textContent = JSON.stringify(data);
    };

    if (activeServiceSlug && SERVICES_SEO_DATA[activeServiceSlug]) {
      const srv = SERVICES_SEO_DATA[activeServiceSlug];
      const canonicalSlug = srv.canonicalSlug || srv.slug;
      const canonicalUrl = `https://www.shamimtechsolution.com/services/${canonicalSlug}`;

      document.title = srv.title;
      setMetaTag('meta[name="description"]', 'name', 'description', srv.metaDescription);
      setCanonical(canonicalUrl);
      updateDynamicRobots(false);

      setMetaTag('meta[property="og:title"]', 'property', 'og:title', srv.title);
      setMetaTag('meta[property="og:description"]', 'property', 'og:description', srv.metaDescription);
      setMetaTag('meta[property="og:url"]', 'property', 'og:url', canonicalUrl);
      setMetaTag('meta[name="twitter:title"]', 'name', 'twitter:title', srv.title);
      setMetaTag('meta[name="twitter:description"]', 'name', 'twitter:description', srv.metaDescription);

      if (srv.popularSearchKeywords && srv.popularSearchKeywords.length > 0) {
        setMetaTag('meta[name="keywords"]', 'name', 'keywords', srv.popularSearchKeywords.join(', '));
      }

      setRouteJsonLd({
        "@context": "https://schema.org",
        "@graph": [
          {
            "@type": "Service",
            "@id": `${canonicalUrl}#service`,
            "name": srv.name,
            "alternateName": srv.bnName,
            "serviceType": srv.category,
            "description": srv.metaDescription,
            "provider": {
              "@type": "LocalBusiness",
              "name": "Shamim Tech Solution",
              "telephone": companyInfo.phone || "01790139333",
              "url": "https://www.shamimtechsolution.com/",
              "address": {
                "@type": "PostalAddress",
                "streetAddress": "Jahaj Company Mor",
                "addressLocality": "Rangpur",
                "addressRegion": "Rangpur Division",
                "addressCountry": "BD"
              }
            },
            "areaServed": [
              "Rangpur", "Haragachh", "Dinajpur", "Bogura", "Dhaka", "Gaibandha", "Kurigram", "Nilphamari", "Lalmonirhat", "Panchagarh", "Thakurgaon"
            ]
          },
          {
            "@type": "BreadcrumbList",
            "itemListElement": [
              { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://www.shamimtechsolution.com/" },
              { "@type": "ListItem", "position": 2, "name": "Services", "item": "https://www.shamimtechsolution.com/#services" },
              { "@type": "ListItem", "position": 3, "name": srv.name, "item": canonicalUrl }
            ]
          },
          ...(srv.faqs && srv.faqs.length > 0 ? [{
            "@type": "FAQPage",
            "mainEntity": srv.faqs.map(faq => ({
              "@type": "Question",
              "name": faq.question,
              "acceptedAnswer": { "@type": "Answer", "text": faq.answer }
            }))
          }] : [])
        ]
      });
    } else if (activeProductSlug && PRODUCTS_SEO_DATA[activeProductSlug]) {
      const prod = PRODUCTS_SEO_DATA[activeProductSlug];
      const canonicalSlug = prod.canonicalSlug || prod.slug;
      const canonicalUrl = `https://www.shamimtechsolution.com/products/${canonicalSlug}`;

      document.title = prod.title;
      setMetaTag('meta[name="description"]', 'name', 'description', prod.metaDescription);
      setCanonical(canonicalUrl);
      updateDynamicRobots(prod.noindex);

      setMetaTag('meta[property="og:title"]', 'property', 'og:title', prod.title);
      setMetaTag('meta[property="og:description"]', 'property', 'og:description', prod.metaDescription);
      setMetaTag('meta[property="og:url"]', 'property', 'og:url', canonicalUrl);
      setMetaTag('meta[name="twitter:title"]', 'name', 'twitter:title', prod.title);
      setMetaTag('meta[name="twitter:description"]', 'name', 'twitter:description', prod.metaDescription);

      setRouteJsonLd({
        "@context": "https://schema.org",
        "@graph": [
          {
            "@type": "Product",
            "@id": `${canonicalUrl}#product`,
            "name": prod.name,
            "alternateName": prod.bnName,
            "description": prod.metaDescription,
            "category": prod.category,
            "brand": {
              "@type": "Brand",
              "name": prod.isInquiryOnly ? prod.name.split(' ')[0] : "Hikvision / Dahua / ZKTeco / Imou"
            },
            "offers": prod.isInquiryOnly ? {
              "@type": "Offer",
              "url": canonicalUrl,
              "seller": {
                "@type": "LocalBusiness",
                "name": "Shamim Tech Solution",
                "telephone": companyInfo.phone || "01790139333",
                "url": "https://www.shamimtechsolution.com/"
              }
            } : {
              "@type": "Offer",
              "priceCurrency": "BDT",
              "price": "1850",
              "availability": "https://schema.org/InStock",
              "seller": {
                "@type": "LocalBusiness",
                "name": "Shamim Tech Solution",
                "telephone": companyInfo.phone || "01790139333",
                "url": "https://www.shamimtechsolution.com/"
              }
            }
          },
          {
            "@type": "BreadcrumbList",
            "itemListElement": [
              { "@type": "ListItem", "position": 1, "name": "Home", "item": "https://www.shamimtechsolution.com/" },
              { "@type": "ListItem", "position": 2, "name": "Products", "item": "https://www.shamimtechsolution.com/#products" },
              { "@type": "ListItem", "position": 3, "name": prod.name, "item": canonicalUrl }
            ]
          },
          ...(prod.faqs && prod.faqs.length > 0 ? [{
            "@type": "FAQPage",
            "mainEntity": prod.faqs.map(faq => ({
              "@type": "Question",
              "name": faq.question,
              "acceptedAnswer": { "@type": "Answer", "text": faq.answer }
            }))
          }] : [])
        ]
      });
    } else if (activeDistrictSlug && DISTRICT_SEO_DATA[activeDistrictSlug]) {
      const dist = DISTRICT_SEO_DATA[activeDistrictSlug];
      const canonicalUrl = `https://www.shamimtechsolution.com/service-area/${dist.slug}`;

      document.title = dist.title;
      setMetaTag('meta[name="description"]', 'name', 'description', dist.metaDescription);
      setCanonical(canonicalUrl);
      updateDynamicRobots(false);

      const districtKeywords = [...(dist.popularSearchesBn || []), ...(dist.popularSearchesEn || [])];
      if (districtKeywords.length > 0) {
        setMetaTag('meta[name="keywords"]', 'name', 'keywords', districtKeywords.join(', '));
      }

      setMetaTag('meta[property="og:title"]', 'property', 'og:title', dist.title);
      setMetaTag('meta[property="og:description"]', 'property', 'og:description', dist.metaDescription);
      setMetaTag('meta[property="og:url"]', 'property', 'og:url', canonicalUrl);
      setRouteJsonLd(null);
    } else {
      document.title = 'Shamim Tech Solution • Security Sales & Service Bangladesh';
      setMetaTag(
        'meta[name="description"]',
        'name',
        'description',
        'শামীম টেক সলিউশন – রংপুর বিভাগে সিসিটিভি ক্যামেরা বিক্রয় ও সার্ভিসিং, আইপি ক্যামেরা সেটআপ, অ্যাক্সেস কন্ট্রোল ও ইলেকট্রিক্যাল সলিউশন। হটলাইন: 01790139333।'
      );
      setCanonical('https://www.shamimtechsolution.com/');
      updateDynamicRobots(false);
      setMetaTag('meta[property="og:title"]', 'property', 'og:title', 'Shamim Tech Solution • Security Sales & Service Bangladesh');
      setMetaTag('meta[property="og:url"]', 'property', 'og:url', 'https://www.shamimtechsolution.com/');
      setRouteJsonLd(null);
    }
  }, [activeDistrictSlug, activeServiceSlug, activeProductSlug, companyInfo.phone]);

  const navigateToDistrict = useCallback((slug: string) => {
    try {
      if (window.location.pathname !== `/service-area/${slug}`) {
        window.history.pushState(null, '', `/service-area/${slug}`);
      }
    } catch {
      window.location.hash = `service-area/${slug}`;
    }
    setActiveDistrictSlug(slug);
    setActiveServiceSlug(null);
    setActiveProductSlug(null);
    setIsAdminRoute(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const navigateToService = useCallback((slug: string) => {
    try {
      if (window.location.pathname !== `/services/${slug}`) {
        window.history.pushState(null, '', `/services/${slug}`);
      }
    } catch {
      window.location.hash = `services/${slug}`;
    }
    setActiveServiceSlug(slug);
    setActiveProductSlug(null);
    setActiveDistrictSlug(null);
    setIsAdminRoute(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const navigateToProduct = useCallback((slug: string) => {
    try {
      if (window.location.pathname !== `/products/${slug}`) {
        window.history.pushState(null, '', `/products/${slug}`);
      }
    } catch {
      window.location.hash = `products/${slug}`;
    }
    setActiveProductSlug(slug);
    setActiveServiceSlug(null);
    setActiveDistrictSlug(null);
    setIsAdminRoute(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const navigateToHome = useCallback(() => {
    try {
      if (window.location.pathname !== '/') {
        window.history.pushState(null, '', '/');
      }
    } catch {
      window.location.hash = '';
    }
    setActiveServiceSlug(null);
    setActiveProductSlug(null);
    setActiveDistrictSlug(null);
    setIsAdminRoute(false);
    setIsAdminDashboardOpen(false);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const navigateToAdmin = useCallback(() => {
    try {
      if (window.location.pathname !== '/admin') {
        window.history.pushState(null, '', '/admin');
      }
    } catch {
      window.location.hash = 'admin';
    }
    setIsAdminRoute(true);
    setIsAdminDashboardOpen(true);
    setActiveDistrictSlug(null);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  }, []);

  const navigateToPublicSite = useCallback(() => {
    navigateToHome();
  }, [navigateToHome]);

  // Synchronize active section based on scroll position
  useEffect(() => {
    const sectionIds = ['home', 'services', 'products', 'gallery', 'about', 'contact'];
    const handleScroll = () => {
      const scrollPosition = window.scrollY + 180;
      for (let i = sectionIds.length - 1; i >= 0; i--) {
        const el = document.getElementById(sectionIds[i]);
        if (el && el.offsetTop <= scrollPosition) {
          setActiveSection(sectionIds[i]);
          break;
        }
      }
    };
    window.addEventListener('scroll', handleScroll, { passive: true });
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Sync cart to localStorage whenever it changes
  useEffect(() => {
    try {
      localStorage.setItem('sts_cctv_cart', JSON.stringify(cartItems));
    } catch (e) {
      console.error('Failed to save cart to localStorage', e);
    }
  }, [cartItems]);

  const showToast = (msg: string) => {
    setToastMessage(msg);
    setTimeout(() => {
      setToastMessage(null);
    }, 3500);
  };

  // Admin authentication handlers
  const handleOpenAdmin = () => {
    navigateToAdmin();
  };

  const handleLoginSuccess = (token: string, user: { username: string; email: string; role: string }) => {
    localStorage.setItem('sts_admin_token', token);
    setAdminToken(token);
    setAdminUser(user);
    setIsAdminLoggedIn(true);
    setIsAdminLoginOpen(false);
    setIsAdminDashboardOpen(true);
    setIsAdminRoute(true);
    if (window.location.pathname !== '/admin') {
      window.history.pushState(null, '', '/admin');
    }
    showToast(`Welcome back, ${user.username}! Admin session active.`);
  };

  const handleAdminLogout = async () => {
    const currentToken = adminToken || localStorage.getItem('sts_admin_token');
    if (currentToken) {
      try {
        await fetch('/api/auth/logout', {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${currentToken}`
          }
        });
      } catch (err) {
        console.warn('Logout API call note:', err);
      }
    }

    localStorage.removeItem('sts_admin_token');
    setAdminToken(null);
    setAdminUser(null);
    setIsAdminLoggedIn(false);
    setIsAdminDashboardOpen(false);
    showToast('Admin logged out successfully.');
  };

  // Cart operations
  const handleAddToCart = (product: Product) => {
    setCartItems((prevItems) => {
      const existingIndex = prevItems.findIndex(i => i.product.id === product.id);
      if (existingIndex > -1) {
        const updated = [...prevItems];
        updated[existingIndex].quantity += 1;
        return updated;
      }
      return [...prevItems, { product, quantity: 1 }];
    });
    showToast(`Added "${product.name}" to cart!`);
  };

  const handleBuyNow = (product: Product) => {
    // Add to cart and immediately open order checkout
    setCartItems((prevItems) => {
      const existingIndex = prevItems.findIndex(i => i.product.id === product.id);
      if (existingIndex > -1) {
        const updated = [...prevItems];
        return updated;
      }
      return [...prevItems, { product, quantity: 1 }];
    });
    setIsOrderModalOpen(true);
  };

  const handleUpdateQuantity = (productId: string, delta: number) => {
    setCartItems((prev) => {
      return prev
        .map((item) => {
          if (item.product.id === productId) {
            const newQty = item.quantity + delta;
            return newQty > 0 ? { ...item, quantity: newQty } : null;
          }
          return item;
        })
        .filter(Boolean) as CartItem[];
    });
  };

  const handleRemoveItem = (productId: string) => {
    setCartItems(prev => prev.filter(i => i.product.id !== productId));
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  const handleOrderPlaced = async (order: SavedOrder) => {
    try {
      const savedOrders = JSON.parse(localStorage.getItem('sts_orders') || '[]');
      localStorage.setItem('sts_orders', JSON.stringify([order, ...savedOrders]));
      
      // Also notify backend server for admin dashboard orders list
      await fetch('/api/public/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(order)
      });
    } catch (e) {
      console.error('Failed to persist order to server', e);
    }
    // Clear the cart
    setCartItems([]);
    showToast(`Order #${order.orderId} placed successfully!`);
  };

  // Scroll helpers
  const scrollToSection = (sectionId: string, offset = 70) => {
    const el = document.getElementById(sectionId);
    if (el) {
      const elementPosition = el.getBoundingClientRect().top + window.scrollY;
      const offsetPosition = Math.max(0, elementPosition - offset);
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  const scrollToProducts = () => {
    setActiveDistrictSlug(null);
    setActiveServiceSlug(null);
    setActiveProductSlug(null);
    const gridEl = document.getElementById('product-items-grid') || document.getElementById('products');
    if (gridEl) {
      const navOffset = 75;
      const elementPosition = gridEl.getBoundingClientRect().top + window.scrollY;
      const offsetPosition = Math.max(0, elementPosition - navOffset);
      window.scrollTo({
        top: offsetPosition,
        behavior: 'smooth'
      });
    }
  };

  const handleCategorySelect = (category: ProductCategory, searchTag?: string) => {
    setActiveDistrictSlug(null);
    setActiveServiceSlug(null);
    setActiveProductSlug(null);
    setSelectedCategory(category);
    if (searchTag) {
      setSearchTerm(searchTag);
    } else {
      setSearchTerm('');
    }
    // Direct scroll to product items grid so user immediately sees product cards like Star Tech
    setTimeout(() => {
      scrollToProducts();
    }, 50);
  };

  const handleServiceSelect = (serviceName?: string) => {
    if (serviceName) {
      setPreselectedService(serviceName);
    }
    setIsContactModalOpen(true);
  };

  const totalCartCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);

  // Dedicated Separate Route: /admin (or #admin)
  if (isAdminRoute) {
    if (isAdminLoggedIn && adminToken) {
      return (
        <AdminDashboard
          token={adminToken}
          adminUser={adminUser || { username: 'admin', email: 'shamimtech2020@gmail.com', role: 'Super Admin' }}
          onLogout={handleAdminLogout}
          onClose={navigateToPublicSite}
          onDataUpdated={loadPublicData}
        />
      );
    }

    // If not logged in, render dedicated standalone Admin Login Portal
    return (
      <AdminLoginPage
        onLoginSuccess={handleLoginSuccess}
        onBackToSite={navigateToPublicSite}
        companyInfo={companyInfo}
      />
    );
  }

  const handleCustomerAuthSuccess = (loggedCustomer: CustomerUser) => {
    setCustomer(loggedCustomer);
    showToast(`স্বাগতম, ${loggedCustomer.fullName}! সফলভাবে লগইন হয়েছে।`);
  };

  const handleCustomerLogout = () => {
    clearCustomerSession();
    setCustomer(null);
    showToast('লগআউট সম্পন্ন হয়েছে।');
  };

  return (
    <div className="min-h-screen w-full max-w-full overflow-x-hidden bg-gradient-to-b from-[#e2f9eb] via-white to-[#e8f5fe] text-slate-800 flex flex-col selection:bg-cyan-500 selection:text-white font-sans antialiased">
      
      {/* Sticky Navigation Bar */}
      <Navbar
        activeSection={activeSection}
        setActiveSection={setActiveSection}
        cartCount={totalCartCount}
        cartItemCount={totalCartCount}
        openCart={() => setIsCartOpen(true)}
        onOpenCart={() => setIsCartOpen(true)}
        openSearch={() => scrollToSection('products')}
        openAuth={() => {
          if (customer) {
            setIsCustomerProfileOpen(true);
          } else {
            setCustomerAuthMode('register');
            setIsCustomerAuthOpen(true);
          }
        }}
        customer={customer}
        onOpenCustomerAuth={(mode) => {
          setCustomerAuthMode(mode || 'register');
          setIsCustomerAuthOpen(true);
        }}
        onOpenCustomerProfile={() => setIsCustomerProfileOpen(true)}
        searchTerm={searchTerm}
        setSearchTerm={setSearchTerm}
        onOpenAdmin={handleOpenAdmin}
        isAdminLoggedIn={isAdminLoggedIn}
        companyInfo={companyInfo}
        products={products}
        onViewProduct={(product) => setSelectedProduct(product)}
        onSelectDistrict={navigateToDistrict}
        onSelectService={navigateToService}
        onSelectProduct={navigateToProduct}
        onNavigateHome={navigateToHome}
        onOpenContact={() => setIsContactModalOpen(true)}
      />

      {/* Floating Action Buttons (WhatsApp & Direct Call) */}
      <FloatingActions
        cartCount={totalCartCount}
        onOpenCart={() => setIsCartOpen(true)}
        companyInfo={companyInfo}
      />

      {/* Toast Notification */}
      {toastMessage && (
        <div className="fixed top-20 right-4 z-50 bg-cyan-950/95 border border-[#06D002]/80 text-cyan-200 px-4 py-3 rounded-xl shadow-[0_0_20px_rgba(5,184,2,0.35)] text-xs sm:text-sm font-semibold flex items-center gap-2 animate-fadeIn backdrop-blur-md">
          <span className="w-2 h-2 rounded-full bg-[#06D002] animate-ping" />
          <span>{toastMessage}</span>
        </div>
      )}

      {/* Main Content Sections - ALWAYS render the original main website across all SEO & search routes */}
      <main className="flex-1 w-full max-w-full overflow-x-hidden">
        <>
          {/* 1. Hero Section */}
          <Hero
            onViewProducts={scrollToProducts}
            onRequestQuote={() => setIsContactModalOpen(true)}
            companyInfo={companyInfo}
            siteContent={siteContent}
            onSelectCategory={handleCategorySelect}
          />

          {/* 2. Services Section (Quick services & 11 detailed services) */}
          <ServicesSection
            onRequestService={handleServiceSelect}
            onSelectDistrict={navigateToDistrict}
          />

          {/* 3. Product Shop with Categories, Search, Cart & BDT pricing */}
          <ProductShop
            products={products}
            onAddToCart={handleAddToCart}
            onBuyNow={handleBuyNow}
            onViewDetails={(product) => setSelectedProduct(product)}
            searchTerm={searchTerm}
            setSearchTerm={setSearchTerm}
            selectedCategory={selectedCategory}
            onSelectCategory={setSelectedCategory}
          />

          {/* 5. Work Gallery with Lightbox and Real Field Projects */}
          <WorkGallery />

          {/* 6. Customer Testimonials & Reviews */}
          <CustomerReviews />

          {/* 8. Contact Section with Working Form & Rangpur Division Map */}
          <ContactSection
            preselectedService={preselectedService}
            companyInfo={companyInfo}
            isContactModalOpen={isContactModalOpen}
            onOpenContactModal={() => setIsContactModalOpen(true)}
            onCloseContactModal={() => setIsContactModalOpen(false)}
          />
        </>
      </main>

      {/* Footer with Admin Portal link */}
      <Footer 
        companyInfo={companyInfo}
        onOpenAdmin={handleOpenAdmin}
        isAdminLoggedIn={isAdminLoggedIn}
        onSelectDistrict={navigateToDistrict}
        activeDistrictSlug={activeDistrictSlug}
      />

      {/* Product Detail Modal */}
      <ProductDetailModal
        product={selectedProduct}
        onClose={() => setSelectedProduct(null)}
        onAddToCart={handleAddToCart}
        onBuyNow={handleBuyNow}
      />

      {/* Shopping Cart Drawer */}
      <CartDrawer
        isOpen={isCartOpen}
        onClose={() => setIsCartOpen(false)}
        items={cartItems}
        onUpdateQuantity={handleUpdateQuantity}
        onRemoveItem={handleRemoveItem}
        onClearCart={handleClearCart}
        onProceedToOrder={() => setIsOrderModalOpen(true)}
      />

      {/* Order Placement Form & WhatsApp Ordering Modal */}
      <OrderModal
        isOpen={isOrderModalOpen}
        onClose={() => setIsOrderModalOpen(false)}
        items={cartItems}
        onOrderPlaced={handleOrderPlaced}
        companyInfo={companyInfo}
        customer={customer}
      />

      {/* Customer Registration / Login / Forgot Password Modal */}
      <CustomerAuthModal
        isOpen={isCustomerAuthOpen}
        onClose={() => setIsCustomerAuthOpen(false)}
        initialMode={customerAuthMode}
        onSuccess={handleCustomerAuthSuccess}
      />

      {/* Customer Profile & Order History Modal */}
      {customer && (
        <CustomerProfileModal
          isOpen={isCustomerProfileOpen}
          onClose={() => setIsCustomerProfileOpen(false)}
          customer={customer}
          onUpdateCustomer={(updated) => {
            setCustomer(updated);
            showToast('প্রোফাইল তথ্য আপডেট সম্পন্ন হয়েছে!');
          }}
          onLogout={handleCustomerLogout}
        />
      )}

      {/* Admin Login Modal (if opened via fallback) */}
      <AdminLoginModal
        isOpen={isAdminLoginOpen}
        onClose={() => setIsAdminLoginOpen(false)}
        onLoginSuccess={handleLoginSuccess}
      />

      {/* Floating Session Badge (Visible ONLY when admin is actively logged in on this browser) */}
      {isAdminLoggedIn && (
        <div className="fixed bottom-4 left-4 z-40 bg-slate-950/95 border border-emerald-500/50 text-emerald-300 px-3 py-2 rounded-xl shadow-[0_0_20px_rgba(16,185,129,0.3)] backdrop-blur-md text-xs font-semibold flex items-center gap-2.5 animate-fadeIn">
          <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping" />
          <span className="font-mono text-[11px] hidden sm:inline">Admin Active</span>
          <button 
            onClick={navigateToAdmin}
            className="px-2.5 py-1 rounded-lg bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-bold text-xs transition-colors cursor-pointer"
          >
            Open /admin
          </button>
          <button 
            onClick={handleAdminLogout}
            className="text-slate-400 hover:text-red-400 text-xs cursor-pointer ml-1"
            title="Logout"
          >
            Logout
          </button>
        </div>
      )}

    </div>
  );
}
